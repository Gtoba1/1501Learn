ShopLink Distribution practice data, batch 1
===========================================

A fictional Lagos electronics distributor. Orders from 2024-01-01 to 2026-06-30.
Amounts are in naira. Timestamps are UTC, formatted YYYY-MM-DD HH:MM:SS.

customers.csv    400 rows    one row per customer account
products.csv     120 rows    one row per product
warehouses.csv   5 rows      one row per warehouse
orders.csv       9091 rows   one row per order
order_lines.csv  26779 rows  one row per product on an order

Net revenue for a line = quantity * unit_price * (1 - discount_pct / 100).
Cancelled and returned orders are not revenue.

This is realistic data, so it is not perfectly clean. Finding and handling
the problems is part of the course. If you want to check your work, these
were planted on purpose:

- orders.status: inconsistent casing and stray spaces (for example 'Delivered', ' shipped', 'CANCELLED')
- order_lines: 6 rows are exact duplicates of another row
- customers.city: about 12 customers have no city
- orders.customer_id: 3 orders point to customers that do not exist
- order_lines.quantity: 2 lines have a quantity of 0 or less
- products.is_active: some inactive products still appear on recent orders
