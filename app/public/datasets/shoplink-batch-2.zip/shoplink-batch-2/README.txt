ShopLink Distribution practice data, batch 2
===========================================

A later extract, taken on 2026-07-31. Load it on top of batch 1.

customers.csv    430 rows    the full customer table again: about 20 existing
                              customers changed (moved, or changed type) with a newer
                              updated_at, plus 30 new customers
orders.csv       565 rows    433 new July orders, plus 132 June orders
                              whose status changed since batch 1 (same order_id,
                              newer updated_at)
order_lines.csv  1230 rows   lines for the new July orders only

Order lines never change once written, so only new orders have lines here.
